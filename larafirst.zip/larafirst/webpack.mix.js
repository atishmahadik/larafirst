let mix = require('laravel-mix');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */

mix.js([
		'resources/assets/js/app.js'
	], 'public/js');
   .sass('resources/assets/sass/app.scss', 'public/css');
   .less('public/css/bootstrap/less/glyphicons.less', 'public/css');
   .styles([
    'public/css/bootstrap.css',
    'public/css/fonts/font-awesome.min.css',
    'css/slider.css',
    'css/mystyle.css',
    'css/contactstyle.css'
	], 'public/css/all.css');
  .copyDirectory('css/fonts', 'public/css/fonts')
